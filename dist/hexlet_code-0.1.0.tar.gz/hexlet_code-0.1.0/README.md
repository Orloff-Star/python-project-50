### Hexlet tests and linter status:

[![Actions Status](https://github.com/Orloff-Star/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Orloff-Star/python-project-50/actions)


Code Climat: <a href="https://codeclimate.com/github/Orloff-Star/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/33303850e645948fbe9d/maintainability" /></a>


Demo step three:
https://asciinema.org/a/Kk96Bjc9TA18qzJmJ37YDcn1z
