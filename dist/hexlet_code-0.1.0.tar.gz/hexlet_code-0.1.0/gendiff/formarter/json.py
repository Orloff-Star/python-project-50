import json


def json_dict(diff):
    return json.dumps(diff)
