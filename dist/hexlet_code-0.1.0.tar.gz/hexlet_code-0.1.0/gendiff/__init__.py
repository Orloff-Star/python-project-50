from gendiff.scripts.search_diff import generate_diff

__all__ = (
    'generate_diff',
)