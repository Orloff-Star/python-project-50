import yaml
import os
import json


def format_yaml(file_path):
    with open(file_path, 'r') as f:
        data = yaml.load(f, Loader=yaml.FullLoader)
    return data


def format_json(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data


def convert_file_to_dict(file_path):
    result = ''
    _, ext = os.path.splitext(file_path)
    if ext == '.yml' or ext == '.yaml':
        result = format_yaml(file_path)
    elif ext == '.json':
        result = format_json(file_path)
    return dict(result)
